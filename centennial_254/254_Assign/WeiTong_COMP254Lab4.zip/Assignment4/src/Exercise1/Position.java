package Exercise1;

public interface Position<E> {
  E getElement();
}
