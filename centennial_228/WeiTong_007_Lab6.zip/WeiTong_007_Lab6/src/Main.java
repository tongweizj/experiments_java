/*
* Name: Wei Tong"
* Student ID: 301034450
*/
public class Main {
    public static void main(String[] args) {
        System.out.println("\nName: Wei Tong");
        System.out.println("Student ID: 301034450\n");
        TransactionTest.main();
    }
}