/*
 * Name: Wei Tong"
 * Student ID: 301034450
 */
public enum TransactionType {DEPOSIT, WITHDRAW
}
